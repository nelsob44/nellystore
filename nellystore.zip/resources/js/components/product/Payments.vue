<template>
    <h1>Payments</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
