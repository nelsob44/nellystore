<template>
    <div>
        <toolbar></toolbar>
        <router-view></router-view>
        <app-footer></app-footer>
        
    </div>
</template>

<script>
import toolbar from './Toolbar'
import AppFooter from './AppFooter'

export default {
name: 'app-home',
components: {toolbar, AppFooter}
}

</script>

<style>

</style>